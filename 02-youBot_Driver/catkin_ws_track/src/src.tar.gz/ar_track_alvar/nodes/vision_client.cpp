


#include <ar_track_alvar_msgs/AlvarMarker.h>
#include <ar_track_alvar_msgs/AlvarMarkers.h>



#include "ros/ros.h"
#include "std_msgs/String.h"

/**
 * This tutorial demonstrates simple receipt of messages over the ROS system.
 */
// %Tag(CALLBACK)%
void visionCallback(const ar_track_alvar_msgs::AlvarMarkers::ConstPtr& msg)
{
//    std::cout<<"jinrujinru";
//    std::cout<<msg->header;
//    std::cout<<sizeof(msg->header)<<std::endl;
    std::cout<<msg->markers.size()<<std::endl;

    if(msg->markers.size()>0)
        std::cout<<msg->markers[0].pose.pose;
}
// %EndTag(CALLBACK)%

int main(int argc, char **argv)
{

  ros::init(argc, argv, "listener");

  ros::NodeHandle n;


  ros::Subscriber sub = n.subscribe("ar_pose_marker", 1000, visionCallback);

  ros::spin();


  return 0;
}
// %EndTag(FULLTEXT)%
