^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package ar_track_alvar_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.5.1 (2015-04-12)
------------------
* Release into Jade ROS
* Contributors: Isaac IY Saito

0.5.0 (2014-06-25)
------------------
* migrate from ar_track_alvar repository
* Contributors: Jihoon Lee
